export default{
    imageProfileView: {
        borderRadius: 25,
        height:50,
        width: 50,
         justifyContent: "flex-start",
        //margin: 5,
        alignSelf: 'center',
       
      },
      imageProfile: { flex: 1, alignSelf: "center", resizeMode: "contain" }
}