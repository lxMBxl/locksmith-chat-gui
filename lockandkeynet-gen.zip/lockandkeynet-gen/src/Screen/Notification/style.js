import Color from '../../Config/Color';
export default{
    icon2:{
        color: Color.whiteSmoke,
        alignSelf: "center",
        marginHorizontal:5,
        marginVertical:12
      },
}