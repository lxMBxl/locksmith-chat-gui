export default{
    text:{fontSize:16,color:'#fff',alignSelf:'center',fontFamily:'uber-b',}
}