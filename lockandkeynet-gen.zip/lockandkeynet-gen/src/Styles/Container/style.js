import Color from '../../Config/Color';
export default{
    container: {
        backgroundColor: Color.white,
        flex: 1,
       
      },
      marginHorizontal:{
        marginHorizontal: 15,
      },
     
}